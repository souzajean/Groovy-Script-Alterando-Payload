import com.sap.gateway.ip.core.customdev.util.Message
import groovy.json.JsonSlurper
import groovy.json.JsonBuilder

Message processData(Message message) {

    // Ler o body como String
    def body = message.getBody(String)
    def json = new JsonSlurper().parseText(body)

    // Dados do cabeçalho
    def loja = json.RegistroCompras.InformacoesGerais.NomeLoja
    def dataCriacao = json.RegistroCompras.InformacoesGerais.Data

    // Lista de transações
    def transacoes = json.RegistroCompras.Transacoes

    // Número total de itens
    def numeroItens = transacoes.size()

    // Número de itens pagos com Cartão de Crédito
    def numeroItensCartao = transacoes.findAll { 
        it.TipoPagamento == "Cartão de Crédito" 
    }.size()

    // Soma total dos preços
    def valorTotal = 0.0
    transacoes.each { item ->
        valorTotal += item.Preco as Double
    }

    // Construção do JSON de saída
    def builder = new JsonBuilder()
    builder {
        Log {
            InformacoesGerais {
                Loja loja
                DataCriacao dataCriacao
            }
            ResumoCartao {
                NumeroItens numeroItens
                NumeroItensCartao numeroItensCartao
                ValorTotal valorTotal
            }
        }
    }

    // Setar o novo body
    message.setBody(builder.toPrettyString())
    return message
}
